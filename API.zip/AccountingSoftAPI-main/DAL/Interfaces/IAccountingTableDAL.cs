﻿using System;
using Entities.Entities;
namespace DAL.Interfaces
{
	public interface IAccountingTableDAL : IDALGeneric<TblAccountingTable>
	{
	}
}

