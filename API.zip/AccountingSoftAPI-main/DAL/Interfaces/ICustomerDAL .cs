﻿using System;
using Entities.Entities;
namespace DAL.Interfaces
{
	public interface ICustomerDAL : IDALGeneric<TblCustomer>
	{
	}
}

