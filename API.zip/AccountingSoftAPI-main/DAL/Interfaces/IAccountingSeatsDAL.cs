﻿using System;
using Entities.Entities;
namespace DAL.Interfaces
{
	public interface IAccountingSeatsDAL : IDALGeneric<TblAccountingSeat>
	{
	}
}

